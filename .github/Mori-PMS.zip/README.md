# Mori-PMS

Hotel & Hospitality Management System: point of sale, kitchen and bar order routing, stock control, front desk, revenue management, reports, staff and role administration, and GDS bookings with commission tracking.

## Modules

- **POS**: waiters take orders by table; cashiers close sales; Manager and Super Admin can void.
- **Orders**: each order splits into a Kitchen ticket and a Bar ticket; departments mark orders Preparing, Ready and Served; tickets and receipts can be printed.
- **Stock**, **Front desk** (check-in/out, occupancy chart), **Revenue and Reports** (daily, monthly, yearly, CSV and printable download), **GDS** bookings with commission, **Business day** (business date, backdated closing), **Settings**, **Staff & admin**.

## How it works

A single static page (`index.html`) talks to a Supabase project:

- **Sign-in:** staff tap their name and enter a 4-digit PIN. The `pin-login` edge function checks the PIN (stored hashed, locks a user for 5 minutes after 5 wrong tries) and returns a normal Supabase session.
- **Shared data:** orders, tickets and settings live in the `docs` table and sync live across tablets with Supabase Realtime. Order numbers come from a database sequence, so they never repeat.
- **Access rules:** the database only answers signed-in staff. Kitchen, Bar, Waiter and Cashier accounts cannot change settings.
- **Staff:** created, removed and PIN-reset through database functions that check the caller's role.

## Set up

1. Host the repository with GitHub Pages (Settings, Pages, deploy from `main`).
2. In Supabase, Authentication, Sign In / Providers, turn **off** "Allow new users to sign up".
3. First sign-in: **Super Admin**, PIN **1234**. Change it straight away under Staff & admin.
4. Register staff under Staff & admin. Kitchen, Bar and Reception tablets stay signed in; waiter and cashier tablets sign out after 2 minutes of no touch.

`supabase/` holds the edge function source and a schema outline.

## Limits

Orders can't be sent while a tablet is offline (it tells the waiter to retry). Staff accounts are not recorded in the audit trail yet.
