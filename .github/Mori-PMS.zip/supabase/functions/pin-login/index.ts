import { createClient } from 'npm:@supabase/supabase-js@2'

const cors = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
  'Access-Control-Allow-Methods': 'POST, OPTIONS',
}
const json = (b: unknown, s = 200) =>
  new Response(JSON.stringify(b), { status: s, headers: { ...cors, 'Content-Type': 'application/json' } })

// PIN sign-in: verifies a staff member's 4-digit PIN (hashed, with lockout) and
// returns a normal Supabase session for that staff member's hidden auth user.
Deno.serve(async (req) => {
  if (req.method === 'OPTIONS') return new Response('ok', { headers: cors })
  try {
    const { staff_id, pin } = await req.json()
    if (typeof staff_id !== 'string' || typeof pin !== 'string' || !/^\d{4}$/.test(pin)) {
      return json({ error: 'Enter your 4-digit PIN.' }, 400)
    }
    const url = Deno.env.get('SUPABASE_URL')!
    const opts = { auth: { persistSession: false, autoRefreshToken: false } }
    const admin = createClient(url, Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!, opts)

    const { data: v, error } = await admin.rpc('verify_pin', { p_staff: staff_id, p_pin: pin })
    if (error || !v?.ok) return json({ error: v?.error || 'Sign-in failed.' }, 401)

    const email = `staff-${v.id}@mori-pms.example.com`
    let uid = v.auth_user_id
    if (!uid) {
      const { data: c, error: ce } = await admin.auth.admin.createUser({
        email,
        email_confirm: true,
        password: crypto.randomUUID() + crypto.randomUUID(),
      })
      if (ce || !c?.user) return json({ error: 'Could not create the sign-in.' }, 500)
      uid = c.user.id
      await admin.from('staff').update({ auth_user_id: uid }).eq('id', v.id)
    }

    const { data: l, error: le } = await admin.auth.admin.generateLink({ type: 'magiclink', email })
    if (le || !l?.properties?.hashed_token) return json({ error: 'Could not start the session.' }, 500)

    const anon = createClient(url, Deno.env.get('SUPABASE_ANON_KEY')!, opts)
    const { data: s, error: se } = await anon.auth.verifyOtp({
      token_hash: l.properties.hashed_token,
      type: 'magiclink',
    })
    if (se || !s?.session) return json({ error: 'Could not start the session.' }, 500)

    return json({
      access_token: s.session.access_token,
      refresh_token: s.session.refresh_token,
      staff: { id: v.id, name: v.name, role: v.role },
    })
  } catch (_e) {
    return json({ error: 'Sign-in failed.' }, 500)
  }
})
