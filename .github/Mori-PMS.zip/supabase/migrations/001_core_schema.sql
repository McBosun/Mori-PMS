-- Mori-PMS core schema (already applied to the hosted project).
create extension if not exists pgcrypto with schema extensions;

create table public.staff (
  id uuid primary key default gen_random_uuid(),
  name text not null check (length(trim(name)) > 0),
  role text not null check (role in ('Super Admin','Admin','Manager','Accountant','Supervisor','Cashier','Waiter/Waitress','Receptionist','Kitchen','Bar')),
  pin_hash text not null,
  auth_user_id uuid unique,
  active boolean not null default true,
  failed_attempts int not null default 0,
  locked_until timestamptz,
  created_at timestamptz not null default now()
);
alter table public.staff enable row level security;  -- no policies: only server functions touch it

create table public.docs (
  coll text not null, id text not null, data jsonb not null,
  updated_at timestamptz not null default now(), updated_by uuid default auth.uid(),
  primary key (coll, id)
);
alter table public.docs enable row level security;
create sequence public.order_no_seq;

-- my_role(), docs policies (orders/tickets: any staff; cfg: not Waiter/Cashier/Kitchen/Bar),
-- staff_list(), me(), next_order_no(), verify_pin() (service role only),
-- admin_add_staff(), admin_delete_staff(), admin_set_pin() and the realtime publication
-- are defined in the migration "mori_pms_core_schema" on the Supabase project;
-- export the full text with: supabase db pull
